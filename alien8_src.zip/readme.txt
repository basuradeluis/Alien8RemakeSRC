There are the C fonts needed to compile the remake of Alien 8.
Don't forget you must link them with the Allegro and FMod librearies.
For any questions or comments, you can e-mail me at perezg_ret@terra.es

Ignacio P�rez Gil.